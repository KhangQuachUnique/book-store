package dao;

public class UserDao {
}
